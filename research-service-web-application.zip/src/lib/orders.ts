import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";

export type Order = typeof orders.$inferSelect;

export async function getOrderWithExpiryCheck(id: number): Promise<Order | null> {
  const rows = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  if (rows.length === 0) return null;
  const order = rows[0];

  if (order.status === "pending_payment" && new Date() > new Date(order.expiresAt)) {
    const [updated] = await db
      .update(orders)
      .set({ status: "expired" })
      .where(eq(orders.id, id))
      .returning();
    return updated;
  }

  return order;
}
