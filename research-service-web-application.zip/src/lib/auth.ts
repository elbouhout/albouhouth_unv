import crypto from "crypto";
import { cookies } from "next/headers";
import bcrypt from "bcryptjs";
import { getSettings } from "@/lib/settings";

const SECRET = process.env.ADMIN_SESSION_SECRET || "albouhouth-unv-default-secret";
export const ADMIN_COOKIE = "albouhouth_admin_token";

function sign(passwordHash: string): string {
  return crypto.createHmac("sha256", SECRET).update(passwordHash).digest("hex");
}

export async function verifyAdminPassword(password: string): Promise<boolean> {
  const settings = await getSettings();
  return bcrypt.compare(password, settings.adminPasswordHash);
}

export async function createAdminToken(): Promise<string> {
  const settings = await getSettings();
  return sign(settings.adminPasswordHash);
}

export async function isAdminAuthenticated(): Promise<boolean> {
  const cookieStore = await cookies();
  const token = cookieStore.get(ADMIN_COOKIE)?.value;
  if (!token) return false;
  const settings = await getSettings();
  const expected = sign(settings.adminPasswordHash);
  try {
    const a = Buffer.from(token);
    const b = Buffer.from(expected);
    if (a.length !== b.length) return false;
    return crypto.timingSafeEqual(a, b);
  } catch {
    return false;
  }
}
