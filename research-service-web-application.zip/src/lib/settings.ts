import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";

export type Settings = typeof settings.$inferSelect;
export type PublicSettings = Omit<Settings, "adminPasswordHash">;

let ensurePromise: Promise<Settings> | null = null;

async function createDefaultSettings(): Promise<Settings> {
  const passwordHash = await bcrypt.hash("admin123", 10);
  const [inserted] = await db
    .insert(settings)
    .values({ adminPasswordHash: passwordHash })
    .returning();
  return inserted;
}

export async function getSettings(): Promise<Settings> {
  const rows = await db.select().from(settings).limit(1);
  if (rows.length > 0) return rows[0];

  if (!ensurePromise) {
    ensurePromise = createDefaultSettings();
  }
  try {
    return await ensurePromise;
  } catch (err) {
    ensurePromise = null;
    const rows2 = await db.select().from(settings).limit(1);
    if (rows2.length > 0) return rows2[0];
    throw err;
  }
}

export function toPublicSettings(s: Settings): PublicSettings {
  const { adminPasswordHash: _hash, ...rest } = s;
  return rest;
}

export async function updateSettings(
  data: Partial<Omit<Settings, "id" | "updatedAt">>,
): Promise<Settings> {
  const current = await getSettings();
  const [updated] = await db
    .update(settings)
    .set({ ...data, updatedAt: new Date() })
    .where(eq(settings.id, current.id))
    .returning();
  return updated;
}
