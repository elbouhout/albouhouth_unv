import { mkdir, writeFile } from "fs/promises";
import path from "path";
import crypto from "crypto";

const ALLOWED_TYPES = new Set(["image/png", "image/jpeg", "image/jpg", "image/webp"]);
const MAX_SIZE = 8 * 1024 * 1024; // 8MB

export async function saveUploadedImage(
  file: File,
  folder: string,
): Promise<string> {
  if (!ALLOWED_TYPES.has(file.type)) {
    throw new Error("نوع الملف غير مدعوم، الرجاء رفع صورة (png, jpg, webp)");
  }
  if (file.size > MAX_SIZE) {
    throw new Error("حجم الملف كبير جدا (الحد الأقصى 8 ميغابايت)");
  }

  const buffer = Buffer.from(await file.arrayBuffer());
  const ext = file.type === "image/png" ? "png" : file.type === "image/webp" ? "webp" : "jpg";
  const fileName = `${Date.now()}-${crypto.randomBytes(6).toString("hex")}.${ext}`;

  const dir = path.join(process.cwd(), "storage", "uploads", folder);
  await mkdir(dir, { recursive: true });
  await writeFile(path.join(dir, fileName), buffer);

  return `/api/uploads/${folder}/${fileName}`;
}
