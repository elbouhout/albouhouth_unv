export function toWhatsappLink(localPhone: string, text: string): string {
  const digits = localPhone.replace(/\D/g, "");
  const international = digits.startsWith("0")
    ? `213${digits.slice(1)}`
    : digits.startsWith("213")
      ? digits
      : `213${digits}`;
  return `https://wa.me/${international}?text=${encodeURIComponent(text)}`;
}
