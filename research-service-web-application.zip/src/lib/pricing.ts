export type PricingSettings = {
  researchPrice: number;
  summaryPrice: number;
  pptPriceFirstFive: number;
  pptPricePerExtraFive: number;
};

export type OrderSelection = {
  wantWord: boolean;
  wantPpt: boolean;
  pptSlides?: number | null;
  wantSummary: boolean;
};

export function computePptPrice(
  slides: number | null | undefined,
  settings: PricingSettings,
): number {
  if (!slides || slides <= 0) return 0;
  const blocks = Math.max(1, Math.round(slides / 5));
  return (
    settings.pptPriceFirstFive +
    (blocks - 1) * settings.pptPricePerExtraFive
  );
}

export function computeTotalPrice(
  selection: OrderSelection,
  settings: PricingSettings,
): number {
  let total = 0;
  if (selection.wantWord) total += settings.researchPrice;
  if (selection.wantPpt) total += computePptPrice(selection.pptSlides, settings);
  if (selection.wantSummary) total += settings.summaryPrice;
  return total;
}

export function formatDzd(amount: number): string {
  return `${amount.toLocaleString("ar-DZ")} دج`;
}
