"use client";

import { useRouter } from "next/navigation";

export default function BackButton({
  label = "رجوع",
  fallbackHref,
  className = "",
}: {
  label?: string;
  fallbackHref?: string;
  className?: string;
}) {
  const router = useRouter();

  return (
    <button
      type="button"
      onClick={() => {
        if (fallbackHref) {
          router.push(fallbackHref);
        } else {
          router.back();
        }
      }}
      className={
        "inline-flex items-center gap-2 rounded-full border border-[#d4af37]/40 bg-[#1a1a1f] px-4 py-2 text-sm text-slate-200 transition hover:border-[#d4af37] hover:text-[#d4af37] " +
        className
      }
    >
      <span aria-hidden>→</span>
      {label}
    </button>
  );
}
