"use client";

export default function WhatsappFloatingButton({ whatsappNumber }: { whatsappNumber: string }) {
  const digits = whatsappNumber.replace(/\D/g, "");
  const international = digits.startsWith("0") ? `213${digits.slice(1)}` : digits;
  const href = `https://wa.me/${international}?text=${encodeURIComponent(
    "مرحبا، أريد الاستفسار عن خدمات albouhouth unv",
  )}`;

  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer"
      className="fixed bottom-5 left-5 z-50 flex items-center gap-2 rounded-full bg-[#25D366] px-4 py-3 text-sm font-bold text-white shadow-lg shadow-black/40 transition hover:scale-105"
    >
      <svg viewBox="0 0 32 32" className="h-5 w-5 fill-white">
        <path d="M16 0C7.163 0 0 7.163 0 16c0 2.837.744 5.5 2.04 7.805L0 32l8.4-2.01A15.9 15.9 0 0 0 16 32c8.837 0 16-7.163 16-16S24.837 0 16 0zm0 29.09c-2.49 0-4.82-.68-6.82-1.86l-.49-.29-4.98 1.19 1.22-4.85-.32-.5A13.06 13.06 0 0 1 2.9 16C2.9 8.77 8.77 2.9 16 2.9S29.1 8.77 29.1 16 23.23 29.09 16 29.09zm7.17-9.78c-.39-.2-2.31-1.14-2.67-1.27-.36-.13-.62-.2-.88.2-.26.39-1 1.27-1.23 1.53-.23.26-.45.29-.84.1-.39-.2-1.63-.6-3.11-1.92-1.15-1.02-1.92-2.28-2.15-2.67-.23-.39-.02-.6.17-.79.17-.17.39-.45.58-.68.2-.23.26-.39.39-.65.13-.26.07-.49-.03-.68-.1-.2-.88-2.11-1.2-2.89-.32-.76-.64-.66-.88-.67h-.75c-.26 0-.68.1-1.04.49-.36.39-1.36 1.33-1.36 3.24s1.4 3.76 1.59 4.02c.2.26 2.75 4.2 6.67 5.89.93.4 1.66.64 2.23.82.94.3 1.79.26 2.47.16.75-.11 2.31-.94 2.64-1.86.33-.92.33-1.7.23-1.86-.1-.17-.36-.26-.75-.46z" />
      </svg>
      تواصل عبر واتساب
    </a>
  );
}
