import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
} from "drizzle-orm/pg-core";

export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  siteName: text("site_name").notNull().default("albouhouth unv"),
  logoUrl: text("logo_url").notNull().default("/images/logo.png"),
  whatsappNumber: text("whatsapp_number").notNull().default("0773150164"),
  baridimobNumber: text("baridimob_number")
    .notNull()
    .default("00799999004278464857"),
  welcomeMessage: text("welcome_message")
    .notNull()
    .default(
      "مرحبا بك 👋\nيرجى إرسال المبلغ إلى حساب بريدي موب (BaridiMob) التالي:\n00799999004278464857\nوعند إتمام التحويل قم بمراسلتنا على واتساب لإكمال الحديث معنا على الرقم: 0773150164",
    ),
  researchPrice: integer("research_price").notNull().default(800),
  summaryPrice: integer("summary_price").notNull().default(100),
  pptPriceFirstFive: integer("ppt_price_first_five").notNull().default(800),
  pptPricePerExtraFive: integer("ppt_price_per_extra_five")
    .notNull()
    .default(800),
  chatTimeoutMinutes: integer("chat_timeout_minutes").notNull().default(5),
  adminPasswordHash: text("admin_password_hash").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  researchTitle: text("research_title").notNull(),
  wantWord: boolean("want_word").notNull().default(false),
  wordStyle: text("word_style"),
  wantPpt: boolean("want_ppt").notNull().default(false),
  pptSlides: integer("ppt_slides"),
  wantSummary: boolean("want_summary").notNull().default(false),
  fullName: text("full_name").notNull(),
  teamMembers: text("team_members").notNull().default(""),
  phone: text("phone").notNull(),
  academicYear: text("academic_year").notNull(),
  fawj: text("fawj").notNull().default(""),
  majmoua: text("majmoua").notNull().default(""),
  specialty: text("specialty").notNull().default(""),
  professorName: text("professor_name").notNull().default(""),
  totalPrice: integer("total_price").notNull().default(0),
  status: text("status").notNull().default("pending_payment"),
  proofImageUrl: text("proof_image_url"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  sender: text("sender").notNull(), // 'system' | 'admin' | 'customer'
  content: text("content"),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
