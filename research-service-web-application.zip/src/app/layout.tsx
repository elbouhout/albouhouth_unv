import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Tajawal } from "next/font/google";
import "./globals.css";

const tajawal = Tajawal({
  subsets: ["arabic", "latin"],
  weight: ["300", "400", "500", "700", "800", "900"],
  variable: "--font-tajawal",
});

export const metadata: Metadata = {
  title: "albouhouth unv | البحوث الجامعية",
  description: "منصة albouhouth unv لإنشاء وطلب البحوث الجامعية وعروض البوربوينت والملخصات.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className={tajawal.variable}>
      <body className="min-h-screen bg-[#0b0b0f] font-[var(--font-tajawal)] text-slate-100 antialiased">
        {children}
      </body>
    </html>
  );
}
