import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders, messages } from "@/db/schema";
import { desc } from "drizzle-orm";
import { getSettings } from "@/lib/settings";
import { computeTotalPrice } from "@/lib/pricing";
import { isAdminAuthenticated } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const authed = await isAdminAuthenticated();
  if (!authed) {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }
  const all = await db.select().from(orders).orderBy(desc(orders.createdAt));
  return NextResponse.json({ orders: all });
}

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => null);
  if (!body) {
    return NextResponse.json({ error: "بيانات غير صحيحة" }, { status: 400 });
  }

  const {
    researchTitle,
    wantWord,
    wordStyle,
    wantPpt,
    pptSlides,
    wantSummary,
    fullName,
    teamMembers,
    phone,
    academicYear,
    fawj,
    majmoua,
    specialty,
    professorName,
  } = body;

  if (!researchTitle || typeof researchTitle !== "string" || !researchTitle.trim()) {
    return NextResponse.json({ error: "اسم البحث مطلوب" }, { status: 400 });
  }
  if (!wantWord && !wantPpt) {
    return NextResponse.json(
      { error: "يجب اختيار بحث (وورد) أو عرض بوربوينت على الأقل" },
      { status: 400 },
    );
  }
  if (wantWord && !wordStyle) {
    return NextResponse.json(
      { error: "الرجاء اختيار طريقة تنسيق البحث" },
      { status: 400 },
    );
  }
  if (wantPpt && (!pptSlides || pptSlides % 5 !== 0 || pptSlides <= 0)) {
    return NextResponse.json(
      { error: "عدد شرائح البوربوينت يجب أن يكون من مضاعفات 5" },
      { status: 400 },
    );
  }
  if (!fullName || !phone || !academicYear) {
    return NextResponse.json(
      { error: "الاسم واللقب ورقم الهاتف والسنة الجامعية مطلوبة" },
      { status: 400 },
    );
  }

  const settings = await getSettings();
  const totalPrice = computeTotalPrice(
    { wantWord: !!wantWord, wantPpt: !!wantPpt, pptSlides, wantSummary: !!wantSummary },
    settings,
  );

  const now = new Date();
  const expiresAt = new Date(now.getTime() + settings.chatTimeoutMinutes * 60 * 1000);

  const [order] = await db
    .insert(orders)
    .values({
      researchTitle: researchTitle.trim(),
      wantWord: !!wantWord,
      wordStyle: wantWord ? wordStyle : null,
      wantPpt: !!wantPpt,
      pptSlides: wantPpt ? pptSlides : null,
      wantSummary: !!wantSummary,
      fullName,
      teamMembers: teamMembers || "",
      phone,
      academicYear,
      fawj: fawj || "",
      majmoua: majmoua || "",
      specialty: specialty || "",
      professorName: professorName || "",
      totalPrice,
      status: "pending_payment",
      createdAt: now,
      expiresAt,
    })
    .returning();

  await db.insert(messages).values({
    orderId: order.id,
    sender: "system",
    content: settings.welcomeMessage,
  });

  return NextResponse.json({ order });
}
