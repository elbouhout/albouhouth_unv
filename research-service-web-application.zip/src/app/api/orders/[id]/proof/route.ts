import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { messages, orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getOrderWithExpiryCheck } from "@/lib/orders";
import { saveUploadedImage } from "@/lib/upload";
import { getSettings } from "@/lib/settings";
import { toWhatsappLink } from "@/lib/whatsapp";

export const dynamic = "force-dynamic";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const orderId = parseInt(id, 10);
  if (!Number.isFinite(orderId)) {
    return NextResponse.json({ error: "طلب غير صحيح" }, { status: 400 });
  }

  const order = await getOrderWithExpiryCheck(orderId);
  if (!order) {
    return NextResponse.json({ error: "الطلب غير موجود" }, { status: 404 });
  }

  if (order.status !== "pending_payment") {
    return NextResponse.json(
      { error: "انتهت المهلة المحددة لهذا الطلب أو تم التعامل معه مسبقا" },
      { status: 410 },
    );
  }

  const form = await request.formData();
  const file = form.get("file");
  if (!(file instanceof File) || file.size === 0) {
    return NextResponse.json({ error: "الرجاء اختيار صورة" }, { status: 400 });
  }

  let imageUrl: string;
  try {
    imageUrl = await saveUploadedImage(file, "payments");
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "فشل رفع الصورة" },
      { status: 400 },
    );
  }

  const [updatedOrder] = await db
    .update(orders)
    .set({ status: "proof_submitted", proofImageUrl: imageUrl })
    .where(eq(orders.id, orderId))
    .returning();

  await db.insert(messages).values({
    orderId,
    sender: "customer",
    content: "تم إرسال صورة إثبات التحويل المالي ✅",
    imageUrl,
  });

  const settings = await getSettings();
  const waText = `مرحبا، لقد قمت بتحويل المبلغ الخاص بالطلب رقم #${orderId} (${order.researchTitle}). أرجو تأكيد الاستلام ومتابعة الطلب.`;
  const whatsappLink = toWhatsappLink(settings.whatsappNumber, waText);

  await db.insert(messages).values({
    orderId,
    sender: "system",
    content:
      "شكرا لك، تم استلام إثبات الدفع. سيتم تحويلك الآن إلى واتساب لإكمال الحديث مع الإدارة.",
  });

  return NextResponse.json({ order: updatedOrder, whatsappLink });
}
