import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { messages, orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { isAdminAuthenticated } from "@/lib/auth";
import { getOrderWithExpiryCheck } from "@/lib/orders";

export const dynamic = "force-dynamic";

export async function POST(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const authed = await isAdminAuthenticated();
  if (!authed) {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }

  const { id } = await params;
  const orderId = parseInt(id, 10);
  if (!Number.isFinite(orderId)) {
    return NextResponse.json({ error: "طلب غير صحيح" }, { status: 400 });
  }

  const order = await getOrderWithExpiryCheck(orderId);
  if (!order) {
    return NextResponse.json({ error: "الطلب غير موجود" }, { status: 404 });
  }

  const [updated] = await db
    .update(orders)
    .set({ status: "confirmed" })
    .where(eq(orders.id, orderId))
    .returning();

  await db.insert(messages).values({
    orderId,
    sender: "system",
    content: "تم تأكيد استلام الدفع من طرف الإدارة ✅ شكرا لثقتكم في albouhouth unv",
  });

  return NextResponse.json({ order: updated });
}
