import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { messages } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { getOrderWithExpiryCheck } from "@/lib/orders";
import { isAdminAuthenticated } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const orderId = parseInt(id, 10);
  if (!Number.isFinite(orderId)) {
    return NextResponse.json({ error: "طلب غير صحيح" }, { status: 400 });
  }

  const order = await getOrderWithExpiryCheck(orderId);
  if (!order) {
    return NextResponse.json({ error: "الطلب غير موجود" }, { status: 404 });
  }

  const thread = await db
    .select()
    .from(messages)
    .where(eq(messages.orderId, orderId))
    .orderBy(asc(messages.createdAt));

  return NextResponse.json({ order, messages: thread });
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const orderId = parseInt(id, 10);
  if (!Number.isFinite(orderId)) {
    return NextResponse.json({ error: "طلب غير صحيح" }, { status: 400 });
  }

  const order = await getOrderWithExpiryCheck(orderId);
  if (!order) {
    return NextResponse.json({ error: "الطلب غير موجود" }, { status: 404 });
  }

  const body = await request.json().catch(() => null);
  const content = body?.content;
  if (!content || typeof content !== "string" || !content.trim()) {
    return NextResponse.json({ error: "الرسالة فارغة" }, { status: 400 });
  }

  const isAdmin = await isAdminAuthenticated();

  if (order.status === "expired" || order.status === "cancelled") {
    return NextResponse.json({ error: "انتهت صلاحية هذا الطلب" }, { status: 410 });
  }

  if (!isAdmin) {
    if (order.status === "pending_payment") {
      return NextResponse.json(
        {
          error:
            "لا يمكنك إرسال رسالة قبل إرسال صورة إثبات التحويل المالي أولا",
        },
        { status: 403 },
      );
    }
  }

  const [message] = await db
    .insert(messages)
    .values({
      orderId,
      sender: isAdmin ? "admin" : "customer",
      content: content.trim(),
    })
    .returning();

  return NextResponse.json({ message });
}
