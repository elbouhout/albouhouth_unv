import { NextRequest, NextResponse } from "next/server";
import { getOrderWithExpiryCheck } from "@/lib/orders";

export const dynamic = "force-dynamic";

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const orderId = parseInt(id, 10);
  if (!Number.isFinite(orderId)) {
    return NextResponse.json({ error: "طلب غير صحيح" }, { status: 400 });
  }

  const order = await getOrderWithExpiryCheck(orderId);
  if (!order) {
    return NextResponse.json({ error: "الطلب غير موجود" }, { status: 404 });
  }

  return NextResponse.json({ order });
}
