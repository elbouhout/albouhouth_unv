import { NextRequest, NextResponse } from "next/server";
import { isAdminAuthenticated } from "@/lib/auth";
import { getSettings, toPublicSettings, updateSettings } from "@/lib/settings";
import { saveUploadedImage } from "@/lib/upload";
import bcrypt from "bcryptjs";

export const dynamic = "force-dynamic";

export async function GET() {
  const authed = await isAdminAuthenticated();
  if (!authed) {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }
  const settings = await getSettings();
  return NextResponse.json({ settings: toPublicSettings(settings) });
}

export async function PUT(request: NextRequest) {
  const authed = await isAdminAuthenticated();
  if (!authed) {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }

  const form = await request.formData();

  const getStr = (key: string) => {
    const v = form.get(key);
    return typeof v === "string" ? v : undefined;
  };
  const getInt = (key: string) => {
    const v = getStr(key);
    if (v === undefined || v === "") return undefined;
    const n = parseInt(v, 10);
    return Number.isFinite(n) ? n : undefined;
  };

  const update: Record<string, unknown> = {};

  const siteName = getStr("siteName");
  if (siteName) update.siteName = siteName;

  const whatsappNumber = getStr("whatsappNumber");
  if (whatsappNumber) update.whatsappNumber = whatsappNumber;

  const baridimobNumber = getStr("baridimobNumber");
  if (baridimobNumber) update.baridimobNumber = baridimobNumber;

  const welcomeMessage = getStr("welcomeMessage");
  if (welcomeMessage) update.welcomeMessage = welcomeMessage;

  const researchPrice = getInt("researchPrice");
  if (researchPrice !== undefined) update.researchPrice = researchPrice;

  const summaryPrice = getInt("summaryPrice");
  if (summaryPrice !== undefined) update.summaryPrice = summaryPrice;

  const pptPriceFirstFive = getInt("pptPriceFirstFive");
  if (pptPriceFirstFive !== undefined) update.pptPriceFirstFive = pptPriceFirstFive;

  const pptPricePerExtraFive = getInt("pptPricePerExtraFive");
  if (pptPricePerExtraFive !== undefined)
    update.pptPricePerExtraFive = pptPricePerExtraFive;

  const chatTimeoutMinutes = getInt("chatTimeoutMinutes");
  if (chatTimeoutMinutes !== undefined)
    update.chatTimeoutMinutes = chatTimeoutMinutes;

  const newPassword = getStr("newPassword");
  if (newPassword && newPassword.trim().length >= 4) {
    update.adminPasswordHash = await bcrypt.hash(newPassword.trim(), 10);
  }

  const logoFile = form.get("logo");
  if (logoFile instanceof File && logoFile.size > 0) {
    try {
      update.logoUrl = await saveUploadedImage(logoFile, "branding");
    } catch (err) {
      return NextResponse.json(
        { error: err instanceof Error ? err.message : "فشل رفع الشعار" },
        { status: 400 },
      );
    }
  }

  const updated = await updateSettings(update);
  return NextResponse.json({ settings: toPublicSettings(updated) });
}
