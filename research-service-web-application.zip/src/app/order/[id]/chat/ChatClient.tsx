"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import Link from "next/link";
import BackButton from "@/components/BackButton";
import { formatDzd } from "@/lib/pricing";
import type { PublicSettings } from "@/lib/settings";
import type { Order } from "@/lib/orders";

type OrderState = Omit<Order, "expiresAt" | "createdAt"> & {
  expiresAt: string | Date;
  createdAt: string | Date;
};

type Message = {
  id: number;
  orderId: number;
  sender: string;
  content: string | null;
  imageUrl: string | null;
  createdAt: string | Date;
};

const STATUS_LABELS: Record<string, { text: string; color: string }> = {
  pending_payment: { text: "بانتظار الدفع", color: "bg-yellow-500/20 text-yellow-300 border-yellow-500/40" },
  proof_submitted: { text: "تم إرسال إثبات الدفع", color: "bg-blue-500/20 text-blue-300 border-blue-500/40" },
  confirmed: { text: "تم تأكيد الدفع", color: "bg-green-500/20 text-green-300 border-green-500/40" },
  expired: { text: "انتهت المهلة", color: "bg-red-500/20 text-red-300 border-red-500/40" },
  cancelled: { text: "ملغى", color: "bg-red-500/20 text-red-300 border-red-500/40" },
};

export default function ChatClient({
  initialOrder,
  initialMessages,
  settings,
}: {
  initialOrder: OrderState;
  initialMessages: Message[];
  settings: PublicSettings;
}) {
  const [order, setOrder] = useState<OrderState>(initialOrder);
  const [msgs, setMsgs] = useState<Message[]>(initialMessages);
  const [remaining, setRemaining] = useState<number>(() =>
    Math.max(0, new Date(initialOrder.expiresAt).getTime() - Date.now()),
  );
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [whatsappLink, setWhatsappLink] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch(`/api/orders/${order.id}/messages`, { cache: "no-store" });
      if (!res.ok) return;
      const data = await res.json();
      setOrder(data.order);
      setMsgs(data.messages);
    } catch {
      // ignore transient network errors
    }
  }, [order.id]);

  useEffect(() => {
    const interval = setInterval(refresh, 3000);
    return () => clearInterval(interval);
  }, [refresh]);

  useEffect(() => {
    const interval = setInterval(() => {
      setRemaining(Math.max(0, new Date(order.expiresAt).getTime() - Date.now()));
    }, 1000);
    return () => clearInterval(interval);
  }, [order.expiresAt]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs]);

  const minutes = Math.floor(remaining / 60000);
  const seconds = Math.floor((remaining % 60000) / 1000);
  const isLocked = order.status === "expired" || order.status === "cancelled";
  const canChat = order.status === "proof_submitted" || order.status === "confirmed";

  async function sendMessage() {
    if (!text.trim()) return;
    setSending(true);
    setError(null);
    try {
      const res = await fetch(`/api/orders/${order.id}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: text.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "تعذر إرسال الرسالة");
      } else {
        setText("");
        await refresh();
      }
    } catch {
      setError("تعذر الاتصال بالخادم");
    } finally {
      setSending(false);
    }
  }

  async function handleUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setError(null);
    try {
      const form = new FormData();
      form.append("file", file);
      const res = await fetch(`/api/orders/${order.id}/proof`, { method: "POST", body: form });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "تعذر رفع الصورة");
      } else {
        setOrder(data.order);
        setWhatsappLink(data.whatsappLink);
        await refresh();
        if (data.whatsappLink) {
          window.open(data.whatsappLink, "_blank");
        }
      }
    } catch {
      setError("تعذر الاتصال بالخادم");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  function copyBaridimob() {
    navigator.clipboard.writeText(settings.baridimobNumber).catch(() => {});
  }

  const statusInfo = STATUS_LABELS[order.status] ?? { text: order.status, color: "bg-white/10 text-slate-300" };

  return (
    <main className="mx-auto flex min-h-screen max-w-2xl flex-col bg-[#0b0b0f] px-3 py-4 sm:px-4 sm:py-6">
      <div className="mb-3 flex items-center justify-between">
        <BackButton fallbackHref="/order/new" label="رجوع" />
        <Link href="/" className="text-sm font-bold text-gold">albouhouth unv</Link>
      </div>

      <div className="card rounded-2xl p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <p className="text-xs text-slate-400">طلب رقم #{order.id}</p>
            <p className="font-bold text-white">{order.researchTitle}</p>
          </div>
          <span className={`rounded-full border px-3 py-1 text-xs font-bold ${statusInfo.color}`}>
            {statusInfo.text}
          </span>
        </div>

        <div className="mt-3 flex items-center justify-between rounded-xl bg-[#1a1a1f] px-4 py-3">
          <span className="text-sm text-slate-300">السعر الإجمالي</span>
          <span className="text-lg font-extrabold text-gold">{formatDzd(order.totalPrice)}</span>
        </div>

        {!isLocked && order.status === "pending_payment" && (
          <div className="mt-3 flex items-center justify-between rounded-xl border border-[#d4af37]/40 bg-[#d4af37]/10 px-4 py-3">
            <span className="text-sm text-slate-200">الوقت المتبقي لإتمام التحويل</span>
            <span className="font-mono text-xl font-extrabold text-gold">
              {String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")}
            </span>
          </div>
        )}
      </div>

      <div className="card my-4 flex-1 overflow-y-auto rounded-2xl p-4" style={{ minHeight: 320, maxHeight: 460 }}>
        <div className="flex flex-col gap-3">
          {msgs.map((m) => (
            <ChatBubble key={m.id} message={m} />
          ))}
          <div ref={bottomRef} />
        </div>
      </div>

      {error && (
        <div className="mb-3 rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-2 text-sm text-red-300">
          {error}
        </div>
      )}

      {isLocked ? (
        <div className="card rounded-2xl p-5 text-center">
          <p className="mb-3 font-bold text-red-300">
            {order.status === "expired"
              ? "⏰ انتهت المهلة المحددة لإتمام التحويل، تم إغلاق هذا الطلب تلقائيا."
              : "تم إلغاء هذا الطلب."}
          </p>
          <Link href="/order/new" className="btn-gold inline-block rounded-full px-6 py-3">
            إنشاء طلب جديد
          </Link>
        </div>
      ) : order.status === "pending_payment" ? (
        <div className="card space-y-3 rounded-2xl p-4">
          <div className="flex items-center justify-between rounded-xl bg-[#1a1a1f] px-4 py-3">
            <div dir="ltr" className="font-mono text-sm text-slate-100">
              {settings.baridimobNumber}
            </div>
            <button
              onClick={copyBaridimob}
              className="rounded-full border border-[#d4af37]/50 px-3 py-1 text-xs text-gold hover:bg-[#d4af37]/10"
            >
              نسخ الرقم
            </button>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleUpload}
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="btn-gold w-full rounded-full py-3 text-base"
          >
            {uploading ? "جار الإرسال..." : "📎 إرسال صورة إثبات التحويل"}
          </button>
          <p className="text-center text-xs text-slate-500">
            لا يمكنك إرسال رسالة نصية قبل إرسال صورة إثبات الدفع
          </p>
        </div>
      ) : (
        <div className="card space-y-3 rounded-2xl p-4">
          {whatsappLink && (
            <a
              href={whatsappLink}
              target="_blank"
              rel="noreferrer"
              className="block w-full rounded-full bg-[#25D366] py-3 text-center font-bold text-white"
            >
              💬 متابعة الحديث على واتساب
            </a>
          )}
          <div className="flex gap-2">
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") sendMessage();
              }}
              placeholder="اكتب رسالتك..."
              disabled={!canChat || sending}
              className="flex-1 rounded-xl border border-white/10 bg-[#1a1a1f] px-4 py-3 text-sm outline-none focus:border-[#d4af37]"
            />
            <button
              onClick={sendMessage}
              disabled={!canChat || sending || !text.trim()}
              className="btn-gold rounded-xl px-5 text-sm"
            >
              إرسال
            </button>
          </div>
        </div>
      )}
    </main>
  );
}

function ChatBubble({ message }: { message: Message }) {
  const isSystem = message.sender === "system";
  const isCustomer = message.sender === "customer";

  if (isSystem) {
    return (
      <div className="mx-auto max-w-[90%] rounded-xl bg-[#d4af37]/10 px-4 py-2 text-center text-xs leading-6 text-slate-200 whitespace-pre-line">
        {message.content}
      </div>
    );
  }

  return (
    <div className={`flex ${isCustomer ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm ${
          isCustomer ? "bg-[#d4af37] text-black" : "bg-[#23232b] text-slate-100"
        }`}
      >
        {!isCustomer && <p className="mb-1 text-[10px] font-bold opacity-70">الإدارة</p>}
        {message.content && <p className="whitespace-pre-line">{message.content}</p>}
        {message.imageUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={message.imageUrl} alt="إثبات الدفع" className="mt-2 max-h-64 rounded-lg" />
        )}
      </div>
    </div>
  );
}
