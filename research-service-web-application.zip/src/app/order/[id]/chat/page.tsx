import { notFound } from "next/navigation";
import { getOrderWithExpiryCheck } from "@/lib/orders";
import { db } from "@/db";
import { messages as messagesTable } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { getSettings, toPublicSettings } from "@/lib/settings";
import ChatClient from "./ChatClient";

export const dynamic = "force-dynamic";

export default async function OrderChatPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const orderId = parseInt(id, 10);
  if (!Number.isFinite(orderId)) notFound();

  const order = await getOrderWithExpiryCheck(orderId);
  if (!order) notFound();

  const thread = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.orderId, orderId))
    .orderBy(asc(messagesTable.createdAt));

  const settings = await getSettings();

  return (
    <ChatClient
      initialOrder={order}
      initialMessages={thread}
      settings={toPublicSettings(settings)}
    />
  );
}
