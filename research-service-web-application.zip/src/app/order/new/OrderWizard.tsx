"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import BackButton from "@/components/BackButton";
import { computeTotalPrice, computePptPrice, formatDzd } from "@/lib/pricing";
import type { PublicSettings } from "@/lib/settings";

const WORD_STYLES = [
  { value: "فهرس", label: "فهرس" },
  { value: "فصول", label: "فصول" },
  { value: "مباحث", label: "مباحث" },
  { value: "غير ذلك", label: "غير ذلك" },
];

const SLIDE_OPTIONS = Array.from({ length: 8 }, (_, i) => (i + 1) * 5); // 5..40

export default function OrderWizard({ settings }: { settings: PublicSettings }) {
  const router = useRouter();
  const [step, setStep] = useState<1 | 2>(1);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [researchTitle, setResearchTitle] = useState("");
  const [wantWord, setWantWord] = useState(true);
  const [wordStyle, setWordStyle] = useState("فهرس");
  const [wantPpt, setWantPpt] = useState(false);
  const [pptSlides, setPptSlides] = useState(5);
  const [wantSummary, setWantSummary] = useState(false);

  const [fullName, setFullName] = useState("");
  const [teamMembers, setTeamMembers] = useState("");
  const [phone, setPhone] = useState("");
  const [academicYear, setAcademicYear] = useState("");
  const [fawj, setFawj] = useState("");
  const [majmoua, setMajmoua] = useState("");
  const [specialty, setSpecialty] = useState("");
  const [professorName, setProfessorName] = useState("");

  const totalPrice = useMemo(
    () =>
      computeTotalPrice(
        { wantWord, wantPpt, pptSlides: wantPpt ? pptSlides : null, wantSummary },
        settings,
      ),
    [wantWord, wantPpt, pptSlides, wantSummary, settings],
  );

  const pptPrice = useMemo(
    () => computePptPrice(wantPpt ? pptSlides : null, settings),
    [wantPpt, pptSlides, settings],
  );

  function validateStep1(): string | null {
    if (!researchTitle.trim()) return "الرجاء إدخال اسم البحث";
    if (!wantWord && !wantPpt) return "اختر بحث Word أو عرض Power Point على الأقل";
    if (wantWord && !wordStyle) return "اختر طريقة تنسيق البحث";
    return null;
  }

  function validateStep2(): string | null {
    if (!fullName.trim()) return "الرجاء إدخال الاسم واللقب";
    if (!phone.trim()) return "الرجاء إدخال رقم الهاتف";
    if (!academicYear.trim()) return "الرجاء إدخال السنة الجامعية";
    return null;
  }

  function goNext() {
    const err = validateStep1();
    if (err) {
      setError(err);
      return;
    }
    setError(null);
    setStep(2);
  }

  async function handleSubmit() {
    const err = validateStep2();
    if (err) {
      setError(err);
      return;
    }
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          researchTitle,
          wantWord,
          wordStyle: wantWord ? wordStyle : null,
          wantPpt,
          pptSlides: wantPpt ? pptSlides : null,
          wantSummary,
          fullName,
          teamMembers,
          phone,
          academicYear,
          fawj,
          majmoua,
          specialty,
          professorName,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "حدث خطأ أثناء إنشاء الطلب");
        setSubmitting(false);
        return;
      }
      router.push(`/order/${data.order.id}/chat`);
    } catch {
      setError("تعذر الاتصال بالخادم، حاول مجددا");
      setSubmitting(false);
    }
  }

  return (
    <main className="min-h-screen bg-[#0b0b0f] px-4 py-8 sm:py-12">
      <div className="mx-auto max-w-2xl">
        <div className="mb-6 flex items-center justify-between">
          <BackButton fallbackHref={step === 2 ? undefined : "/"} label={step === 2 ? "رجوع" : "الرئيسية"} />
          <Link href="/" className="text-sm font-bold text-gold">albouhouth unv</Link>
        </div>

        <div className="card mb-6 rounded-2xl p-4">
          <div className="flex items-center gap-3 text-sm">
            <StepDot active={step >= 1} label="1" text="تفاصيل الطلب" />
            <div className="h-px flex-1 bg-[#d4af37]/30" />
            <StepDot active={step >= 2} label="2" text="بيانات الطالب" />
          </div>
        </div>

        {error && (
          <div className="mb-4 rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-300">
            {error}
          </div>
        )}

        {step === 1 && (
          <div className="card space-y-6 rounded-2xl p-6">
            <h1 className="text-xl font-extrabold text-white">ما هي تفاصيل بحثك؟</h1>

            <div>
              <label className="mb-2 block text-sm text-slate-300">اسم البحث</label>
              <input
                value={researchTitle}
                onChange={(e) => setResearchTitle(e.target.value)}
                placeholder="مثال: التسويق الرقمي وأثره على المؤسسات"
                className="w-full rounded-xl border border-white/10 bg-[#1a1a1f] px-4 py-3 text-sm outline-none focus:border-[#d4af37]"
              />
            </div>

            <div className="rounded-xl border border-white/10 p-4">
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={wantWord}
                  onChange={(e) => setWantWord(e.target.checked)}
                  className="h-5 w-5 accent-[#d4af37]"
                />
                <span className="font-bold">بحث مكتوب (Word) — {settings.researchPrice} دج</span>
              </label>

              {wantWord && (
                <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
                  {WORD_STYLES.map((s) => (
                    <button
                      type="button"
                      key={s.value}
                      onClick={() => setWordStyle(s.value)}
                      className={`rounded-lg border px-3 py-2 text-sm transition ${
                        wordStyle === s.value
                          ? "border-[#d4af37] bg-[#d4af37]/15 text-gold"
                          : "border-white/10 text-slate-300 hover:border-white/30"
                      }`}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="rounded-xl border border-white/10 p-4">
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={wantPpt}
                  onChange={(e) => setWantPpt(e.target.checked)}
                  className="h-5 w-5 accent-[#d4af37]"
                />
                <span className="font-bold">
                  عرض Power Point — {settings.pptPriceFirstFive} دج لكل 5 شرائح
                </span>
              </label>

              {wantPpt && (
                <div className="mt-4">
                  <label className="mb-2 block text-sm text-slate-300">عدد الشرائح</label>
                  <select
                    value={pptSlides}
                    onChange={(e) => setPptSlides(parseInt(e.target.value, 10))}
                    className="w-full rounded-xl border border-white/10 bg-[#1a1a1f] px-4 py-3 text-sm outline-none focus:border-[#d4af37]"
                  >
                    {SLIDE_OPTIONS.map((n) => (
                      <option key={n} value={n}>
                        {n} شرائح — {formatDzd(computePptPrice(n, settings))}
                      </option>
                    ))}
                  </select>
                  <p className="mt-2 text-xs text-slate-500">سعر هذا الاختيار: {formatDzd(pptPrice)}</p>
                </div>
              )}
            </div>

            <div className="rounded-xl border border-white/10 p-4">
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={wantSummary}
                  onChange={(e) => setWantSummary(e.target.checked)}
                  className="h-5 w-5 accent-[#d4af37]"
                />
                <span className="font-bold">طلب ملخص للبحث — {settings.summaryPrice} دج</span>
              </label>
            </div>

            <div className="flex items-center justify-between rounded-xl bg-[#1a1a1f] px-4 py-3">
              <span className="text-sm text-slate-300">السعر الإجمالي</span>
              <span className="text-xl font-extrabold text-gold">{formatDzd(totalPrice)}</span>
            </div>

            <button onClick={goNext} className="btn-gold w-full rounded-full py-3 text-base">
              التالي
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="card space-y-5 rounded-2xl p-6">
            <h1 className="text-xl font-extrabold text-white">بيانات الطالب والفريق</h1>

            <Field label="الاسم واللقب" value={fullName} onChange={setFullName} placeholder="مثال: محمد بن علي" />
            <div>
              <label className="mb-2 block text-sm text-slate-300">أسماء أعضاء الفريق (إن وجد)</label>
              <textarea
                value={teamMembers}
                onChange={(e) => setTeamMembers(e.target.value)}
                rows={3}
                placeholder="اكتب أسماء الأعضاء مفصولة بفاصلة"
                className="w-full rounded-xl border border-white/10 bg-[#1a1a1f] px-4 py-3 text-sm outline-none focus:border-[#d4af37]"
              />
            </div>
            <Field label="رقم الهاتف" value={phone} onChange={setPhone} placeholder="05XXXXXXXX" type="tel" />
            <div className="grid grid-cols-2 gap-4">
              <Field label="السنة الجامعية" value={academicYear} onChange={setAcademicYear} placeholder="مثال: سنة ثانية ماستر" />
              <Field label="التخصص" value={specialty} onChange={setSpecialty} placeholder="مثال: علوم مالية" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Field label="الفوج" value={fawj} onChange={setFawj} placeholder="مثال: 03" />
              <Field label="المجموعة" value={majmoua} onChange={setMajmoua} placeholder="مثال: 02" />
            </div>
            <Field label="اسم الأستاذ" value={professorName} onChange={setProfessorName} placeholder="مثال: د. فلان الفلاني" />

            <div className="flex items-center justify-between rounded-xl bg-[#1a1a1f] px-4 py-3">
              <span className="text-sm text-slate-300">السعر الإجمالي</span>
              <span className="text-xl font-extrabold text-gold">{formatDzd(totalPrice)}</span>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setStep(1)}
                type="button"
                className="flex-1 rounded-full border border-white/15 py-3 text-sm text-slate-200 hover:border-[#d4af37]"
              >
                رجوع
              </button>
              <button
                onClick={handleSubmit}
                disabled={submitting}
                className="btn-gold flex-1 rounded-full py-3 text-base"
              >
                {submitting ? "جار الإنشاء..." : "إنشاء الطلب"}
              </button>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}

function StepDot({ active, label, text }: { active: boolean; label: string; text: string }) {
  return (
    <div className="flex items-center gap-2">
      <span
        className={`flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold ${
          active ? "bg-[#d4af37] text-black" : "bg-white/10 text-slate-400"
        }`}
      >
        {label}
      </span>
      <span className={active ? "text-slate-100" : "text-slate-500"}>{text}</span>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm text-slate-300">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full rounded-xl border border-white/10 bg-[#1a1a1f] px-4 py-3 text-sm outline-none focus:border-[#d4af37]"
      />
    </div>
  );
}
