import Image from "next/image";
import Link from "next/link";
import { getSettings } from "@/lib/settings";
import WhatsappFloatingButton from "@/components/WhatsappFloatingButton";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const settings = await getSettings();

  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top,_#1c1c22,_#0b0b0f_60%)] px-4 py-10 sm:py-16">
      <div className="mx-auto flex max-w-5xl flex-col items-center gap-8 text-center">
        <div className="relative h-32 w-32 overflow-hidden rounded-full border-4 border-[#d4af37] shadow-[0_0_40px_rgba(212,175,55,0.35)] sm:h-40 sm:w-40">
          <Image src={settings.logoUrl} alt={settings.siteName} fill sizes="160px" className="object-cover" priority />
        </div>

        <div>
          <h1 className="text-3xl font-extrabold sm:text-5xl">
            <span className="text-white">albouhouth</span>{" "}
            <span className="gold-gradient">unv</span>
          </h1>
          <p className="mt-3 text-base text-slate-300 sm:text-lg">
            منصتك الأولى لإنجاز البحوث الجامعية، عروض البوربوينت والملخصات باحترافية وسرعة
          </p>
        </div>

        <div className="grid w-full grid-cols-1 gap-4 sm:grid-cols-3">
          <div className="card rounded-2xl p-5">
            <p className="text-sm text-slate-400">بحث جامعي (Word)</p>
            <p className="mt-2 text-2xl font-extrabold text-gold">{settings.researchPrice} دج</p>
            <p className="mt-1 text-xs text-slate-500">فهرس / فصول / مباحث / حسب الطلب</p>
          </div>
          <div className="card rounded-2xl p-5">
            <p className="text-sm text-slate-400">عرض Power Point</p>
            <p className="mt-2 text-2xl font-extrabold text-gold">{settings.pptPriceFirstFive} دج</p>
            <p className="mt-1 text-xs text-slate-500">لكل 5 شرائح، وتزيد تدريجيا</p>
          </div>
          <div className="card rounded-2xl p-5">
            <p className="text-sm text-slate-400">ملخص البحث</p>
            <p className="mt-2 text-2xl font-extrabold text-gold">{settings.summaryPrice} دج</p>
            <p className="mt-1 text-xs text-slate-500">خدمة إضافية اختيارية</p>
          </div>
        </div>

        <Link
          href="/order/new"
          className="btn-gold pulse-ring w-full max-w-sm rounded-full px-8 py-4 text-lg sm:w-auto"
        >
          ابدأ طلب بحثك الآن ✍️
        </Link>

        <div className="card mt-6 w-full rounded-2xl p-6 text-right">
          <h2 className="mb-3 text-lg font-bold text-gold">كيف تتم العملية؟</h2>
          <ol className="list-inside list-decimal space-y-2 text-sm leading-7 text-slate-300">
            <li>تختار نوع العمل (بحث Word / عرض Power Point / ملخص) ثم تملأ بياناتك الجامعية.</li>
            <li>يتم إنشاء طلبك وتفتح لك صفحة دفع خاصة، فيها مهلة محدودة لإتمام التحويل.</li>
            <li>ترسل المبلغ إلى حساب بريدي موب الظاهر في الصفحة، ثم ترفق صورة إثبات التحويل.</li>
            <li>بعد إرسال الإثبات، يتم تحويلك تلقائيا إلى واتساب لإكمال الحديث مع فريقنا.</li>
          </ol>
        </div>

        <p className="text-xs text-slate-500">
          للتواصل المباشر: واتساب {settings.whatsappNumber}
        </p>

        <Link href="/admin/login" className="text-[11px] text-slate-600 underline underline-offset-4 hover:text-slate-400">
          دخول الإدارة
        </Link>
      </div>

      <WhatsappFloatingButton whatsappNumber={settings.whatsappNumber} />
    </main>
  );
}
