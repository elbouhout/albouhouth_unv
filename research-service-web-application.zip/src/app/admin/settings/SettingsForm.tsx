"use client";

import { useRef, useState } from "react";
import type { PublicSettings } from "@/lib/settings";

export default function SettingsForm({ initialSettings }: { initialSettings: PublicSettings }) {
  const [settings, setSettings] = useState(initialSettings);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState("");
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: "ok" | "err"; text: string } | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  function update<K extends keyof PublicSettings>(key: K, value: PublicSettings[K]) {
    setSettings((s) => ({ ...s, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setMessage(null);
    try {
      const form = new FormData();
      form.append("siteName", settings.siteName);
      form.append("whatsappNumber", settings.whatsappNumber);
      form.append("baridimobNumber", settings.baridimobNumber);
      form.append("welcomeMessage", settings.welcomeMessage);
      form.append("researchPrice", String(settings.researchPrice));
      form.append("summaryPrice", String(settings.summaryPrice));
      form.append("pptPriceFirstFive", String(settings.pptPriceFirstFive));
      form.append("pptPricePerExtraFive", String(settings.pptPricePerExtraFive));
      form.append("chatTimeoutMinutes", String(settings.chatTimeoutMinutes));
      if (newPassword.trim()) form.append("newPassword", newPassword.trim());
      if (fileRef.current?.files?.[0]) form.append("logo", fileRef.current.files[0]);

      const res = await fetch("/api/admin/settings", { method: "PUT", body: form });
      const data = await res.json();
      if (!res.ok) {
        setMessage({ type: "err", text: data.error || "تعذر حفظ الإعدادات" });
      } else {
        setSettings(data.settings);
        setLogoPreview(null);
        setNewPassword("");
        setMessage({ type: "ok", text: "تم حفظ الإعدادات بنجاح ✅" });
      }
    } catch {
      setMessage({ type: "err", text: "تعذر الاتصال بالخادم" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="card space-y-6 rounded-2xl p-6">
      {message && (
        <div
          className={`rounded-xl border px-4 py-3 text-sm ${
            message.type === "ok"
              ? "border-green-500/40 bg-green-500/10 text-green-300"
              : "border-red-500/40 bg-red-500/10 text-red-300"
          }`}
        >
          {message.text}
        </div>
      )}

      <div>
        <p className="mb-2 text-sm text-slate-300">شعار الموقع</p>
        <div className="flex items-center gap-4">
          <div className="relative h-20 w-20 overflow-hidden rounded-full border-2 border-[#d4af37]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={logoPreview || settings.logoUrl}
              alt="logo"
              className="h-full w-full object-cover"
            />
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) setLogoPreview(URL.createObjectURL(f));
            }}
            className="text-sm text-slate-300"
          />
        </div>
      </div>

      <TextField label="اسم الموقع" value={settings.siteName} onChange={(v) => update("siteName", v)} />
      <TextField
        label="رقم واتساب (بصيغة محلية مثال 0773150164)"
        value={settings.whatsappNumber}
        onChange={(v) => update("whatsappNumber", v)}
        dir="ltr"
      />
      <TextField
        label="رقم حساب بريدي موب (BaridiMob)"
        value={settings.baridimobNumber}
        onChange={(v) => update("baridimobNumber", v)}
        dir="ltr"
      />

      <div>
        <label className="mb-2 block text-sm text-slate-300">رسالة الترحيب في صفحة الدفع</label>
        <textarea
          value={settings.welcomeMessage}
          onChange={(e) => update("welcomeMessage", e.target.value)}
          rows={5}
          className="w-full rounded-xl border border-white/10 bg-[#1a1a1f] px-4 py-3 text-sm outline-none focus:border-[#d4af37]"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <NumberField label="سعر البحث (Word) بالدج" value={settings.researchPrice} onChange={(v) => update("researchPrice", v)} />
        <NumberField label="سعر الملخص بالدج" value={settings.summaryPrice} onChange={(v) => update("summaryPrice", v)} />
        <NumberField
          label="سعر أول 5 شرائح PPT"
          value={settings.pptPriceFirstFive}
          onChange={(v) => update("pptPriceFirstFive", v)}
        />
        <NumberField
          label="سعر كل 5 شرائح إضافية"
          value={settings.pptPricePerExtraFive}
          onChange={(v) => update("pptPricePerExtraFive", v)}
        />
      </div>

      <NumberField
        label="مدة مهلة الدفع (بالدقائق)"
        value={settings.chatTimeoutMinutes}
        onChange={(v) => update("chatTimeoutMinutes", v)}
      />

      <div>
        <label className="mb-2 block text-sm text-slate-300">تغيير كلمة مرور الإدارة (اختياري)</label>
        <input
          type="password"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          placeholder="اتركه فارغا للإبقاء على كلمة المرور الحالية"
          className="w-full rounded-xl border border-white/10 bg-[#1a1a1f] px-4 py-3 text-sm outline-none focus:border-[#d4af37]"
        />
      </div>

      <button disabled={saving} className="btn-gold w-full rounded-full py-3 text-base">
        {saving ? "جار الحفظ..." : "حفظ الإعدادات"}
      </button>
    </form>
  );
}

function TextField({
  label,
  value,
  onChange,
  dir,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  dir?: "ltr" | "rtl";
}) {
  return (
    <div>
      <label className="mb-2 block text-sm text-slate-300">{label}</label>
      <input
        dir={dir}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-xl border border-white/10 bg-[#1a1a1f] px-4 py-3 text-sm outline-none focus:border-[#d4af37]"
      />
    </div>
  );
}

function NumberField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm text-slate-300">{label}</label>
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value, 10) || 0)}
        className="w-full rounded-xl border border-white/10 bg-[#1a1a1f] px-4 py-3 text-sm outline-none focus:border-[#d4af37]"
      />
    </div>
  );
}
