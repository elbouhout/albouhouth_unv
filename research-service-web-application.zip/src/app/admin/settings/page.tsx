import { redirect } from "next/navigation";
import { isAdminAuthenticated } from "@/lib/auth";
import { getSettings, toPublicSettings } from "@/lib/settings";
import AdminNav from "../AdminNav";
import SettingsForm from "./SettingsForm";

export const dynamic = "force-dynamic";

export default async function AdminSettingsPage() {
  const authed = await isAdminAuthenticated();
  if (!authed) redirect("/admin/login");

  const settings = await getSettings();

  return (
    <main className="min-h-screen bg-[#0b0b0f] px-4 py-8">
      <div className="mx-auto max-w-3xl">
        <h1 className="mb-6 text-2xl font-extrabold text-gold">إعدادات الموقع</h1>
        <AdminNav />
        <SettingsForm initialSettings={toPublicSettings(settings)} />
      </div>
    </main>
  );
}
