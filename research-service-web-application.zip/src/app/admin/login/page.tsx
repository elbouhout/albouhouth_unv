"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function AdminLoginPage() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "كلمة المرور غير صحيحة");
      } else {
        router.push("/admin");
        router.refresh();
      }
    } catch {
      setError("تعذر الاتصال بالخادم");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="grid min-h-screen place-items-center bg-[#0b0b0f] px-4">
      <form onSubmit={handleSubmit} className="card w-full max-w-sm rounded-2xl p-6">
        <h1 className="mb-1 text-center text-xl font-extrabold text-gold">لوحة تحكم الإدارة</h1>
        <p className="mb-6 text-center text-xs text-slate-500">albouhouth unv</p>

        <label className="mb-2 block text-sm text-slate-300">كلمة المرور</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="mb-4 w-full rounded-xl border border-white/10 bg-[#1a1a1f] px-4 py-3 text-sm outline-none focus:border-[#d4af37]"
        />

        {error && <p className="mb-3 text-sm text-red-400">{error}</p>}

        <button disabled={loading} className="btn-gold w-full rounded-full py-3">
          {loading ? "جار الدخول..." : "دخول"}
        </button>

        <Link href="/" className="mt-4 block text-center text-xs text-slate-500 hover:text-slate-300">
          العودة إلى الموقع
        </Link>
      </form>
    </main>
  );
}
