import { redirect } from "next/navigation";
import Link from "next/link";
import { isAdminAuthenticated } from "@/lib/auth";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { desc } from "drizzle-orm";
import AdminNav from "./AdminNav";
import { formatDzd } from "@/lib/pricing";

export const dynamic = "force-dynamic";

const STATUS_LABELS: Record<string, { text: string; color: string }> = {
  pending_payment: { text: "بانتظار الدفع", color: "bg-yellow-500/20 text-yellow-300 border-yellow-500/40" },
  proof_submitted: { text: "إثبات مرسل", color: "bg-blue-500/20 text-blue-300 border-blue-500/40" },
  confirmed: { text: "مؤكد", color: "bg-green-500/20 text-green-300 border-green-500/40" },
  expired: { text: "منتهي", color: "bg-red-500/20 text-red-300 border-red-500/40" },
  cancelled: { text: "ملغى", color: "bg-red-500/20 text-red-300 border-red-500/40" },
};

export default async function AdminDashboardPage() {
  const authed = await isAdminAuthenticated();
  if (!authed) redirect("/admin/login");

  const all = await db.select().from(orders).orderBy(desc(orders.createdAt));

  return (
    <main className="min-h-screen bg-[#0b0b0f] px-4 py-8">
      <div className="mx-auto max-w-5xl">
        <h1 className="mb-6 text-2xl font-extrabold text-gold">لوحة تحكم الطلبات</h1>
        <AdminNav />

        <div className="card overflow-x-auto rounded-2xl p-2">
          <table className="w-full min-w-[720px] text-right text-sm">
            <thead>
              <tr className="text-slate-400">
                <th className="px-3 py-3">#</th>
                <th className="px-3 py-3">اسم البحث</th>
                <th className="px-3 py-3">الطالب</th>
                <th className="px-3 py-3">الهاتف</th>
                <th className="px-3 py-3">السعر</th>
                <th className="px-3 py-3">الحالة</th>
                <th className="px-3 py-3">التاريخ</th>
                <th className="px-3 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {all.map((o) => {
                const status = STATUS_LABELS[o.status] ?? { text: o.status, color: "bg-white/10 text-slate-300" };
                return (
                  <tr key={o.id} className="border-t border-white/5 hover:bg-white/5">
                    <td className="px-3 py-3 text-slate-400">{o.id}</td>
                    <td className="px-3 py-3 font-bold text-white">{o.researchTitle}</td>
                    <td className="px-3 py-3">{o.fullName}</td>
                    <td className="px-3 py-3" dir="ltr">{o.phone}</td>
                    <td className="px-3 py-3 text-gold">{formatDzd(o.totalPrice)}</td>
                    <td className="px-3 py-3">
                      <span className={`rounded-full border px-2 py-1 text-xs font-bold ${status.color}`}>
                        {status.text}
                      </span>
                    </td>
                    <td className="px-3 py-3 text-xs text-slate-500">
                      {new Date(o.createdAt).toLocaleString("ar-DZ")}
                    </td>
                    <td className="px-3 py-3">
                      <Link
                        href={`/admin/orders/${o.id}`}
                        className="rounded-full border border-[#d4af37]/50 px-3 py-1 text-xs text-gold hover:bg-[#d4af37]/10"
                      >
                        فتح المحادثة
                      </Link>
                    </td>
                  </tr>
                );
              })}
              {all.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-3 py-8 text-center text-slate-500">
                    لا توجد طلبات حتى الآن
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </main>
  );
}
