import { redirect, notFound } from "next/navigation";
import { isAdminAuthenticated } from "@/lib/auth";
import { getOrderWithExpiryCheck } from "@/lib/orders";
import { db } from "@/db";
import { messages as messagesTable } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { getSettings, toPublicSettings } from "@/lib/settings";
import AdminNav from "../../AdminNav";
import AdminChatClient from "./AdminChatClient";

export const dynamic = "force-dynamic";

export default async function AdminOrderPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const authed = await isAdminAuthenticated();
  if (!authed) redirect("/admin/login");

  const { id } = await params;
  const orderId = parseInt(id, 10);
  if (!Number.isFinite(orderId)) notFound();

  const order = await getOrderWithExpiryCheck(orderId);
  if (!order) notFound();

  const thread = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.orderId, orderId))
    .orderBy(asc(messagesTable.createdAt));

  const settings = await getSettings();

  return (
    <main className="min-h-screen bg-[#0b0b0f] px-4 py-8">
      <div className="mx-auto max-w-5xl">
        <h1 className="mb-6 text-2xl font-extrabold text-gold">تفاصيل الطلب #{order.id}</h1>
        <AdminNav />
        <AdminChatClient
          initialOrder={order}
          initialMessages={thread}
          settings={toPublicSettings(settings)}
        />
      </div>
    </main>
  );
}
