"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { formatDzd } from "@/lib/pricing";
import { toWhatsappLink } from "@/lib/whatsapp";
import type { PublicSettings } from "@/lib/settings";
import type { Order } from "@/lib/orders";

type Message = {
  id: number;
  orderId: number;
  sender: string;
  content: string | null;
  imageUrl: string | null;
  createdAt: string | Date;
};

type OrderState = Omit<Order, "expiresAt" | "createdAt"> & {
  expiresAt: string | Date;
  createdAt: string | Date;
};

const STATUS_LABELS: Record<string, { text: string; color: string }> = {
  pending_payment: { text: "بانتظار الدفع", color: "bg-yellow-500/20 text-yellow-300 border-yellow-500/40" },
  proof_submitted: { text: "إثبات مرسل", color: "bg-blue-500/20 text-blue-300 border-blue-500/40" },
  confirmed: { text: "مؤكد", color: "bg-green-500/20 text-green-300 border-green-500/40" },
  expired: { text: "منتهي", color: "bg-red-500/20 text-red-300 border-red-500/40" },
  cancelled: { text: "ملغى", color: "bg-red-500/20 text-red-300 border-red-500/40" },
};

export default function AdminChatClient({
  initialOrder,
  initialMessages,
  settings,
}: {
  initialOrder: OrderState;
  initialMessages: Message[];
  settings: PublicSettings;
}) {
  const [order, setOrder] = useState<OrderState>(initialOrder);
  const [msgs, setMsgs] = useState<Message[]>(initialMessages);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch(`/api/orders/${order.id}/messages`, { cache: "no-store" });
      if (!res.ok) return;
      const data = await res.json();
      setOrder(data.order);
      setMsgs(data.messages);
    } catch {
      // ignore
    }
  }, [order.id]);

  useEffect(() => {
    const interval = setInterval(refresh, 3000);
    return () => clearInterval(interval);
  }, [refresh]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs]);

  async function sendMessage() {
    if (!text.trim()) return;
    setSending(true);
    setError(null);
    try {
      const res = await fetch(`/api/orders/${order.id}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: text.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "تعذر إرسال الرسالة");
      } else {
        setText("");
        await refresh();
      }
    } catch {
      setError("تعذر الاتصال بالخادم");
    } finally {
      setSending(false);
    }
  }

  async function confirmPayment() {
    setConfirming(true);
    setError(null);
    try {
      const res = await fetch(`/api/orders/${order.id}/confirm`, { method: "POST" });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "تعذر تأكيد الدفع");
      } else {
        await refresh();
      }
    } catch {
      setError("تعذر الاتصال بالخادم");
    } finally {
      setConfirming(false);
    }
  }

  const statusInfo = STATUS_LABELS[order.status] ?? { text: order.status, color: "bg-white/10 text-slate-300" };
  const customerWaLink = toWhatsappLink(
    order.phone,
    `مرحبا ${order.fullName}، بخصوص طلب البحث رقم #${order.id} (${order.researchTitle}).`,
  );

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
      <div className="card rounded-2xl p-5 lg:col-span-1">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-extrabold text-white">بيانات الطلب</h2>
          <span className={`rounded-full border px-2 py-1 text-xs font-bold ${statusInfo.color}`}>
            {statusInfo.text}
          </span>
        </div>
        <dl className="space-y-2 text-sm">
          <Row label="اسم البحث" value={order.researchTitle} />
          <Row label="الاسم واللقب" value={order.fullName} />
          <Row label="أعضاء الفريق" value={order.teamMembers || "—"} />
          <Row label="الهاتف" value={order.phone} dir="ltr" />
          <Row label="السنة الجامعية" value={order.academicYear} />
          <Row label="التخصص" value={order.specialty || "—"} />
          <Row label="الفوج" value={order.fawj || "—"} />
          <Row label="المجموعة" value={order.majmoua || "—"} />
          <Row label="الأستاذ" value={order.professorName || "—"} />
          <Row
            label="نوع العمل"
            value={[
              order.wantWord ? `Word (${order.wordStyle})` : null,
              order.wantPpt ? `PPT (${order.pptSlides} شرائح)` : null,
              order.wantSummary ? "ملخص" : null,
            ]
              .filter(Boolean)
              .join(" + ")}
          />
          <Row label="السعر الإجمالي" value={formatDzd(order.totalPrice)} highlight />
        </dl>

        {order.proofImageUrl && (
          <div className="mt-4">
            <p className="mb-2 text-xs text-slate-400">صورة إثبات الدفع:</p>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={order.proofImageUrl} alt="إثبات الدفع" className="w-full rounded-xl border border-white/10" />
          </div>
        )}

        <div className="mt-4 flex flex-col gap-2">
          {order.status === "proof_submitted" && (
            <button
              onClick={confirmPayment}
              disabled={confirming}
              className="btn-gold w-full rounded-full py-2 text-sm"
            >
              {confirming ? "جار التأكيد..." : "✅ تأكيد استلام الدفع"}
            </button>
          )}
          <a
            href={customerWaLink}
            target="_blank"
            rel="noreferrer"
            className="block w-full rounded-full bg-[#25D366] py-2 text-center text-sm font-bold text-white"
          >
            💬 مراسلة الزبون عبر واتساب
          </a>
        </div>
      </div>

      <div className="card flex flex-col rounded-2xl p-5 lg:col-span-2">
        <h2 className="mb-3 font-extrabold text-white">المحادثة</h2>
        <div className="flex-1 overflow-y-auto rounded-xl bg-[#101014] p-4" style={{ minHeight: 320, maxHeight: 460 }}>
          <div className="flex flex-col gap-3">
            {msgs.map((m) => (
              <ChatBubble key={m.id} message={m} />
            ))}
            <div ref={bottomRef} />
          </div>
        </div>

        {error && <p className="mt-3 text-sm text-red-400">{error}</p>}

        <div className="mt-4 flex gap-2">
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") sendMessage();
            }}
            placeholder="اكتب ردك على الزبون..."
            className="flex-1 rounded-xl border border-white/10 bg-[#1a1a1f] px-4 py-3 text-sm outline-none focus:border-[#d4af37]"
          />
          <button
            onClick={sendMessage}
            disabled={sending || !text.trim()}
            className="btn-gold rounded-xl px-5 text-sm"
          >
            إرسال
          </button>
        </div>
      </div>
    </div>
  );
}

function Row({
  label,
  value,
  dir,
  highlight,
}: {
  label: string;
  value: string;
  dir?: "ltr" | "rtl";
  highlight?: boolean;
}) {
  return (
    <div className="flex items-center justify-between gap-2 border-b border-white/5 pb-2">
      <dt className="text-slate-400">{label}</dt>
      <dd dir={dir} className={highlight ? "font-extrabold text-gold" : "text-slate-100"}>
        {value}
      </dd>
    </div>
  );
}

function ChatBubble({ message }: { message: Message }) {
  const isSystem = message.sender === "system";
  const isAdmin = message.sender === "admin";

  if (isSystem) {
    return (
      <div className="mx-auto max-w-[90%] rounded-xl bg-[#d4af37]/10 px-4 py-2 text-center text-xs leading-6 text-slate-200 whitespace-pre-line">
        {message.content}
      </div>
    );
  }

  return (
    <div className={`flex ${isAdmin ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm ${
          isAdmin ? "bg-[#d4af37] text-black" : "bg-[#23232b] text-slate-100"
        }`}
      >
        <p className="mb-1 text-[10px] font-bold opacity-70">{isAdmin ? "الإدارة" : "الزبون"}</p>
        {message.content && <p className="whitespace-pre-line">{message.content}</p>}
        {message.imageUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={message.imageUrl} alt="مرفق" className="mt-2 max-h-64 rounded-lg" />
        )}
      </div>
    </div>
  );
}
