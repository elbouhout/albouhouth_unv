"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";

export default function AdminNav() {
  const pathname = usePathname();
  const router = useRouter();

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" });
    router.push("/admin/login");
    router.refresh();
  }

  const linkClass = (href: string) =>
    `rounded-full px-4 py-2 text-sm font-bold transition ${
      pathname === href ? "bg-[#d4af37] text-black" : "text-slate-300 hover:bg-white/10"
    }`;

  return (
    <nav className="card mb-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl p-3">
      <div className="flex items-center gap-2">
        <Link href="/admin" className={linkClass("/admin")}>الطلبات</Link>
        <Link href="/admin/settings" className={linkClass("/admin/settings")}>الإعدادات</Link>
        <Link href="/" className="rounded-full px-4 py-2 text-sm text-slate-400 hover:bg-white/10">عرض الموقع</Link>
      </div>
      <button onClick={logout} className="rounded-full border border-red-500/40 px-4 py-2 text-sm text-red-300 hover:bg-red-500/10">
        تسجيل الخروج
      </button>
    </nav>
  );
}
